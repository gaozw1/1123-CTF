<?php

	function encrypt($str)
	{

		$cryptedstr = "";
		srand(***);

		for ($i =0; $i < strlen($str); $i++)
		{
			$tem = ord(substr($str,$i,1)) ^ rand(0, 255);

			while(strlen($tem)<3)
			{
				$tem = "0".$tem;

			}

			$cryptedstr .= $temp. "";
			
		}

		return $cryptedstr;
	}
	
?>
